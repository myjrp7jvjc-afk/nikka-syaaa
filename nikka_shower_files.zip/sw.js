// Service Worker for Nikka Shower
const CACHE_NAME = 'nikka-shower-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json'
];

// インストール時にキャッシュを作成
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        return cache.addAll(urlsToCache).catch(err => {
          console.log('キャッシュ追加エラー:', err);
          // 一部のファイルが失敗してもインストール続行
          return Promise.resolve();
        });
      })
      .then(() => self.skipWaiting())
  );
});

// アクティベート時に古いキャッシュを削除
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// フェッチ時にキャッシュを優先的に使用
self.addEventListener('fetch', event => {
  // GETリクエストのみ処理
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // キャッシュがあればそれを返す
        if (response) {
          return response;
        }

        // キャッシュがなければネットワークからフェッチ
        return fetch(event.request)
          .then(response => {
            // ネットワークエラーの場合はここに到達しない
            if (!response || response.status !== 200 || response.type === 'error') {
              return response;
            }

            // 成功したレスポンスをキャッシュに追加
            const responseToCache = response.clone();
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return response;
          })
          .catch(() => {
            // ネットワークエラーの場合、キャッシュから返す
            return caches.match(event.request)
              .then(response => {
                if (response) {
                  return response;
                }
                // キャッシュもない場合はオフラインページを返す
                return new Response('オフラインです。インターネット接続を確認してください。', {
                  status: 503,
                  statusText: 'Service Unavailable',
                  headers: new Headers({
                    'Content-Type': 'text/plain'
                  })
                });
              });
          });
      })
  );
});
